// Client-side error logger that POSTs errors to /log
(function(){
  function sendLog(payload){
    try{
      navigator.sendBeacon && navigator.sendBeacon('/log', JSON.stringify(payload));
      if (!navigator.sendBeacon){
        fetch('/log', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).catch(()=>{});
      }
    }catch(e){}
  }

  window.addEventListener('error', function(ev){
    const payload = {type:'error', message: ev.message, filename: ev.filename, lineno: ev.lineno, colno: ev.colno, stack: (ev.error && ev.error.stack) || null};
    sendLog(payload);
  });

  window.addEventListener('unhandledrejection', function(ev){
    const reason = ev.reason;
    const payload = {type:'unhandledrejection', reason: (reason && reason.stack) || String(reason)};
    sendLog(payload);
  });

  // small heartbeat so server log shows page load
  sendLog({type:'load', ua: navigator.userAgent});
})();
