import { WORLD_WIDTH, WORLD_HEIGHT, GRAVITY, TILE_SIZE } from './constants.js';

export const projectiles = [];

export function updateProjectiles(mobs) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
        const proj = projectiles[i];
        proj.x += proj.vx;
        proj.y += proj.vy;
        proj.vy += GRAVITY * 0.3;

        // Check collision with mobs
        for (let mob of mobs) {
            const dx = mob.x + mob.width / 2 - proj.x;
            const dy = mob.y + mob.height / 2 - proj.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < proj.radius + mob.width / 2) {
                mob.takeDamage(proj.damage);
                projectiles.splice(i, 1);
                break;
            }
        }

        // Remove off-screen projectiles
        if (proj.x < 0 || proj.x > WORLD_WIDTH * TILE_SIZE || proj.y > WORLD_HEIGHT * TILE_SIZE) {
            projectiles.splice(i, 1);
        }
    }
}

export function drawProjectiles(ctx, viewX, viewY) {
    ctx.fillStyle = '#FFD700';
    for (let proj of projectiles) {
        const screenX = proj.x - viewX;
        const screenY = proj.y - viewY;
        ctx.beginPath();
        ctx.arc(screenX, screenY, proj.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}
