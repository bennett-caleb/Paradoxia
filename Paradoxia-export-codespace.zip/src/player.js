import { GRAVITY, FRICTION, TILE_SIZE, WORLD_WIDTH, WORLD_HEIGHT } from './constants.js';
import { input } from './input.js';
import { projectiles } from './projectiles.js';

export class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.vx = 0;
        this.vy = 0;
        this.width = 30;
        this.height = 40;
        this.speed = 5;
        this.jumpPower = 12;
        this.isJumping = false;
        this.direction = 1; // 1 = right, -1 = left
        this.health = 100;
        this.maxHealth = 100;
        this.mana = 30;
        this.maxMana = 30;
        this.level = 1;
        this.xp = 0;
        this.xpToNext = 100;
        this.attackCooldown = 0;
        this.lastAttackX = 0;
        this.lastAttackY = 0;
    }

    setWorld(world) { this.world = world; }

    update(mobs, world, canvas) {
        // Handle horizontal movement
        if (input.left) {
            this.vx = -this.speed;
            this.direction = -1;
        } else if (input.right) {
            this.vx = this.speed;
            this.direction = 1;
        } else {
            this.vx *= FRICTION;
        }

        // Apply gravity
        this.vy += GRAVITY;

        // Handle jumping
        if (input.space && !this.isJumping) {
            this.vy = -this.jumpPower;
            this.isJumping = true;
        }

        // Update position
        this.x += this.vx;
        this.y += this.vy;

        // Collision detection - horizontal
        if (world.isSolid(this.x + (this.direction > 0 ? this.width : 0), this.y + this.height - 5)) {
            this.x -= this.vx;
        }

        // Collision detection - vertical
        if (world.isSolid(this.x + this.width / 2, this.y + this.height)) {
            this.y -= this.vy;
            this.vy = 0;
            this.isJumping = false;
        } else if (world.isSolid(this.x + this.width / 2, this.y)) {
            this.vy = 0;
        }

        // World boundaries
        if (this.x < 0) this.x = 0;
        if (this.x + this.width > WORLD_WIDTH * TILE_SIZE) this.x = WORLD_WIDTH * TILE_SIZE - this.width;

        // Fall off world
        if (this.y > WORLD_HEIGHT * TILE_SIZE) {
            this.respawn(canvas);
        }

        // Update attack cooldown
        if (this.attackCooldown > 0) this.attackCooldown--;

        // Handle attacks
        if (input.mouseDown && this.attackCooldown <= 0) {
            this.attack(mobs, canvas);
            this.attackCooldown = 20;
        }

        // Handle magic
        if (input.rightMouseDown && this.mana >= 15) {
            this.castSpell(canvas);
            this.mana -= 15;
            this.attackCooldown = 30;
        }
    }

    attack(mobs, canvas) {
        const attackRange = 60;
        const attackAngleX = input.mouseX - canvas.width / 2;
        const attackAngleY = input.mouseY - canvas.height / 2;
        const distance = Math.sqrt(attackAngleX * attackAngleX + attackAngleY * attackAngleY);
        const normalizedX = attackAngleX / distance;
        const normalizedY = attackAngleY / distance;

        this.lastAttackX = this.x + this.width / 2 + normalizedX * attackRange;
        this.lastAttackY = this.y + this.height / 2 + normalizedY * attackRange;

        // Check collision with mobs
        for (let mob of mobs) {
            const dx = mob.x + mob.width / 2 - (this.x + this.width / 2);
            const dy = mob.y + mob.height / 2 - (this.y + this.height / 2);
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < attackRange + mob.width / 2) {
                const damage = 15 + Math.floor(Math.random() * 10);
                mob.takeDamage(damage);
                mob.vx += normalizedX * 5;
                mob.vy -= 3;
            }
        }
    }

    castSpell(canvas) {
        const spellAngleX = input.mouseX - canvas.width / 2;
        const spellAngleY = input.mouseY - canvas.height / 2;
        const distance = Math.sqrt(spellAngleX * spellAngleX + spellAngleY * spellAngleY);
        const normalizedX = spellAngleX / distance;
        const normalizedY = spellAngleY / distance;

        // Create projectile
        const projectile = {
            x: this.x + this.width / 2,
            y: this.y + this.height / 2,
            vx: normalizedX * 8,
            vy: normalizedY * 8,
            radius: 6,
            damage: 25,
            owner: 'player'
        };
        projectiles.push(projectile);
    }

    takeDamage(amount) {
        this.health -= amount;
        if (this.health < 0) this.health = 0;
        if (this.health === 0) this.respawn();
    }

    gainXP(amount) {
        this.xp += amount;
        if (this.xp >= this.xpToNext) {
            this.levelUp();
        }
    }

    levelUp() {
        this.level++;
        this.xp -= this.xpToNext;
        this.xpToNext = Math.floor(this.xpToNext * 1.5);
        this.maxHealth += 20;
        this.maxMana += 8;
        this.health = this.maxHealth;
        this.mana = this.maxMana;
    }

    respawn(canvas) {
        this.x = canvas.width / 2;
        this.y = TILE_SIZE * 10;
        this.health = this.maxHealth;
        this.vy = 0;
    }

    draw(ctx, viewX, viewY) {
        const screenX = this.x - viewX;
        const screenY = this.y - viewY;

        // Draw player body
        ctx.fillStyle = '#FF6B6B';
        ctx.fillRect(screenX, screenY, this.width, this.height);

        // Draw player head
        ctx.fillStyle = '#FFB6A3';
        ctx.beginPath();
        ctx.arc(screenX + this.width / 2, screenY + 10, 10, 0, Math.PI * 2);
        ctx.fill();

        // Draw eyes
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(screenX + this.width / 2 - 5 + (this.direction > 0 ? 2 : -2), screenY + 8, 3, 0, Math.PI * 2);
        ctx.fill();

        // Draw direction indicator
        ctx.fillStyle = '#FFD93D';
        ctx.fillRect(screenX + (this.direction > 0 ? this.width - 8 : 0), screenY + this.height / 2, 8, 6);

        // Draw health bar
        ctx.fillStyle = '#333';
        ctx.fillRect(screenX - 5, screenY - 15, this.width + 10, 8);
        ctx.fillStyle = '#00FF00';
        ctx.fillRect(screenX - 5, screenY - 15, (this.width + 10) * (this.health / this.maxHealth), 8);
        ctx.strokeStyle = '#fff';
        ctx.strokeRect(screenX - 5, screenY - 15, this.width + 10, 8);

        // Draw attack indicator
        if (this.attackCooldown > 0) {
            ctx.fillStyle = 'rgba(255, 200, 100, 0.5)';
            ctx.beginPath();
            ctx.arc(this.lastAttackX - viewX, this.lastAttackY - viewY, 20, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}
