import { TILE_SIZE, WORLD_WIDTH, WORLD_HEIGHT } from './constants.js';
import { input, bindInput } from './input.js';
import { World } from './world.js';
import { Player } from './player.js';
import { mobs, updateMobs, drawMobs } from './mob.js';
import { projectiles, updateProjectiles, drawProjectiles } from './projectiles.js';
import { updateHUD } from './hud.js';

let canvas = null;
let ctx = null;
let world = null;
let player = null;
let gameRunning = false;

export function init() {
    console.log('INIT FUNCTION CALLED (module)');
    // Acquire canvas and context
    canvas = document.getElementById('gameCanvas');
    if (!canvas) {
        console.error('Canvas element not found: #gameCanvas');
        return;
    }
    ctx = canvas.getContext('2d');
    bindInput(canvas);

    // Initialize world and player
    world = new World();
    player = new Player(TILE_SIZE * 5, TILE_SIZE * 10);
    gameRunning = true;

    // Start game loop
    requestAnimationFrame(gameLoop);
}

function update() {
    if (!gameRunning) return;
    try {
        player.update(mobs, world, canvas);
        updateMobs(player, world);
        updateProjectiles(mobs);

        // Regenerate mana
        if (player.mana < player.maxMana) {
            player.mana += 0.1;
            if (player.mana > player.maxMana) player.mana = player.maxMana;
        }
    } catch (e) {
        console.error('Update error:', e);
        const debugDiv = document.getElementById('debug');
        if (debugDiv) debugDiv.textContent = 'ERROR in update:\n' + e.message;
    }
}

function render() {
    try {
        // Clear canvas
        ctx.fillStyle = '#87CEEB';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw a test rectangle to verify rendering
        ctx.fillStyle = '#FF0000';
        ctx.fillRect(10, 10, 50, 50);

        // Calculate camera position
        const viewX = Math.max(0, Math.min(player.x - canvas.width / 2, WORLD_WIDTH * TILE_SIZE - canvas.width));
        const viewY = Math.max(0, Math.min(player.y - canvas.height / 2, WORLD_HEIGHT * TILE_SIZE - canvas.height));

        // Draw world
        world.draw(ctx, player, canvas);

        // Draw mobs
        drawMobs(ctx, viewX, viewY);

        // Draw projectiles
        drawProjectiles(ctx, viewX, viewY);

        // Draw player
        player.draw(ctx, viewX, viewY);

        // Update HUD
        updateHUD(player);
    } catch (e) {
        console.error('Render error:', e);
        const debugDiv = document.getElementById('debug');
        if (debugDiv) debugDiv.textContent = 'ERROR in render:\n' + e.message + '\n' + e.stack;
    }
}

function gameLoop() {
    if (!gameRunning) return;
    update();
    render();
    const debug = document.getElementById('debug');
    if (debug) {
        debug.textContent = `Game running\nPlayer: ${Math.floor(player.x)}, ${Math.floor(player.y)}\nMobs: ${mobs.length}\nFPS: 60`;
    }
    requestAnimationFrame(gameLoop);
}

// Auto-init similar to the original script
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(init, 100));
} else {
    setTimeout(init, 100);
}
