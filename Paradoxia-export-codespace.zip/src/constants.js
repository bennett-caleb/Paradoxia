// Game constants
export const TILE_SIZE = 40;
export const WORLD_WIDTH = 50;
export const WORLD_HEIGHT = 20;
export const GRAVITY = 0.6;
export const FRICTION = 0.85;
