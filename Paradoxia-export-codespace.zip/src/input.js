export const input = {
    left: false,
    right: false,
    up: false,
    down: false,
    space: false,
    mouseX: 0,
    mouseY: 0,
    mouseDown: false,
    rightMouseDown: false
};

export function bindInput(canvas) {
    window.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') input.left = true;
        if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') input.right = true;
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') input.up = true;
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') input.down = true;
        if (e.key === ' ') { input.space = true; e.preventDefault(); }
    });

    window.addEventListener('keyup', (e) => {
        if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') input.left = false;
        if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') input.right = false;
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') input.up = false;
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') input.down = false;
        if (e.key === ' ') input.space = false;
    });

    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        input.mouseX = e.clientX - rect.left;
        input.mouseY = e.clientY - rect.top;
    });

    canvas.addEventListener('mousedown', (e) => {
        if (e.button === 0) input.mouseDown = true;
        if (e.button === 2) input.rightMouseDown = true;
    });

    canvas.addEventListener('mouseup', (e) => {
        if (e.button === 0) input.mouseDown = false;
        if (e.button === 2) input.rightMouseDown = false;
    });

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
}
