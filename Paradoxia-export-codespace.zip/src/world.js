import { TILE_SIZE, WORLD_WIDTH, WORLD_HEIGHT } from './constants.js';

export class World {
    constructor() {
        this.tiles = [];
        this.generateTerrain();
    }

    generateTerrain() {
        // Create simple terrain with ground
        for (let y = 0; y < WORLD_HEIGHT; y++) {
            this.tiles[y] = [];
            for (let x = 0; x < WORLD_WIDTH; x++) {
                // Create ground platforms
                if (y >= WORLD_HEIGHT - 3) {
                    this.tiles[y][x] = 1; // Ground tile
                } else if (y === WORLD_HEIGHT - 4 && (x % 3 === 0)) {
                    this.tiles[y][x] = 1; // Floating platforms
                } else if (y === WORLD_HEIGHT - 6 && (x % 4 === 1)) {
                    this.tiles[y][x] = 1; // Higher platforms
                } else {
                    this.tiles[y][x] = 0; // Empty space
                }
            }
        }
    }

    getTile(x, y) {
        const tx = Math.floor(x / TILE_SIZE);
        const ty = Math.floor(y / TILE_SIZE);
        if (tx < 0 || tx >= WORLD_WIDTH || ty < 0 || ty >= WORLD_HEIGHT) return 0;
        return this.tiles[ty][tx] || 0;
    }

    isSolid(x, y) {
        return this.getTile(x, y) === 1;
    }

    draw(ctx, player, canvas) {
        const viewX = Math.max(0, Math.min(player.x - canvas.width / 2, WORLD_WIDTH * TILE_SIZE - canvas.width));
        const viewY = Math.max(0, Math.min(player.y - canvas.height / 2, WORLD_HEIGHT * TILE_SIZE - canvas.height));

        const startX = Math.floor(viewX / TILE_SIZE);
        const startY = Math.floor(viewY / TILE_SIZE);
        const endX = Math.ceil((viewX + canvas.width) / TILE_SIZE);
        const endY = Math.ceil((viewY + canvas.height) / TILE_SIZE);

        for (let y = startY; y < endY; y++) {
            for (let x = startX; x < endX; x++) {
                if (this.tiles[y] && this.tiles[y][x] === 1) {
                    const screenX = x * TILE_SIZE - viewX;
                    const screenY = y * TILE_SIZE - viewY;
                    ctx.fillStyle = '#8B6F47';
                    ctx.fillRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
                    ctx.strokeStyle = '#654321';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(screenX, screenY, TILE_SIZE, TILE_SIZE);
                }
            }
        }
    }
}
