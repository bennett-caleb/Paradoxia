export function updateHUD(player) {
    try {
        const healthEl = document.getElementById('health');
        const manaEl = document.getElementById('mana');
        const levelEl = document.getElementById('level');

        if (healthEl) healthEl.textContent = `HP: ${Math.ceil(player.health)}/${player.maxHealth}`;
        if (manaEl) manaEl.textContent = `MP: ${Math.ceil(player.mana)}/${player.maxMana}`;
        if (levelEl) levelEl.textContent = `Level: ${player.level} | XP: ${Math.floor(player.xp)}/${Math.floor(player.xpToNext)}`;
    } catch (e) {
        console.error('HUD update error:', e);
    }
}
