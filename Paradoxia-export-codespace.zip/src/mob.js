import { GRAVITY, WORLD_WIDTH, TILE_SIZE } from './constants.js';

export class Mob {
    constructor(x, y, type = 'goblin') {
        this.x = x;
        this.y = y;
        this.vx = 0;
        this.vy = 0;
        this.type = type;
        this.width = 25;
        this.height = 30;
        this.speed = 2;
        this.health = 30;
        this.maxHealth = 30;
        this.direction = 1;
        this.attackCooldown = 0;
        this.patrolDistance = 100;
        this.patrolLeft = x - this.patrolDistance;
        this.patrolRight = x + this.patrolDistance;
        this.xpValue = 20;
        this.color = this.getColor();
    }

    getColor() {
        const colors = {
            goblin: '#4CAF50',
            orc: '#8B4513',
            skeleton: '#D3D3D3',
            slime: '#90EE90',
            bat: '#4B0082'
        };
        return colors[this.type] || '#666';
    }

    update(player, world) {
        // Simple AI - patrol and chase
        const dx = player.x - this.x;
        const distance = Math.abs(dx);
        const chaseDistance = 150;

        if (distance < chaseDistance) {
            // Chase player
            this.vx = (dx > 0 ? 1 : -1) * this.speed * 1.5;
            this.direction = dx > 0 ? 1 : -1;
        } else {
            // Patrol
            if (this.x < this.patrolLeft) {
                this.vx = this.speed;
                this.direction = 1;
            } else if (this.x > this.patrolRight) {
                this.vx = -this.speed;
                this.direction = -1;
            } else {
                this.vx = (Math.random() > 0.5 ? 1 : -1) * this.speed;
            }
        }

        // Apply gravity
        this.vy += GRAVITY;

        // Update position
        this.x += this.vx;
        this.y += this.vy;

        // Collision detection - horizontal
        if (world.isSolid(this.x + (this.vx > 0 ? this.width : 0), this.y + this.height - 5)) {
            this.x -= this.vx;
            this.vx = -this.vx;
        }

        // Collision detection - vertical
        if (world.isSolid(this.x + this.width / 2, this.y + this.height)) {
            this.y -= this.vy;
            this.vy = 0;
            // Jump occasionally
            if (Math.random() < 0.02) {
                this.vy = -8;
            }
        }

        // Fall off world
        if (this.y > WORLD_HEIGHT * TILE_SIZE) {
            return false; // Mark for removal
        }

        // Attack player if close
        if (distance < 50 && this.attackCooldown <= 0) {
            const damage = 10 + Math.floor(Math.random() * 5);
            player.takeDamage(damage);
            this.attackCooldown = 60;
        }

        if (this.attackCooldown > 0) this.attackCooldown--;

        return true;
    }

    takeDamage(amount) {
        this.health -= amount;
    }

    draw(ctx, viewX, viewY) {
        const screenX = this.x - viewX;
        const screenY = this.y - viewY;

        // Draw mob body
        ctx.fillStyle = this.color;
        ctx.fillRect(screenX, screenY, this.width, this.height);

        // Draw mob eyes
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(screenX + this.width / 2 - 4 + (this.direction > 0 ? 2 : -2), screenY + 8, 3, 0, Math.PI * 2);
        ctx.fill();

        // Draw health bar
        if (this.health < this.maxHealth) {
            ctx.fillStyle = '#333';
            ctx.fillRect(screenX - 2, screenY - 10, this.width + 4, 5);
            ctx.fillStyle = '#FF6B6B';
            ctx.fillRect(screenX - 2, screenY - 10, (this.width + 4) * (this.health / this.maxHealth), 5);
        }
    }
}

export let mobs = [];
let mobSpawnCounter = 0;
const mobSpawnRate = 120;

export function updateMobs(player, world) {
    // Spawn new mobs
    mobSpawnCounter++;
    if (mobSpawnCounter >= mobSpawnRate) {
        const mobTypes = ['goblin', 'orc', 'skeleton', 'slime'];
        const type = mobTypes[Math.floor(Math.random() * mobTypes.length)];
        const spawnX = player.x + (Math.random() > 0.5 ? 300 : -300);
        const spawnY = TILE_SIZE * 10;
        mobs.push(new Mob(spawnX, spawnY, type));
        mobSpawnCounter = 0;
    }

    // Update existing mobs
    for (let i = mobs.length - 1; i >= 0; i--) {
        const alive = mobs[i].update(player, world);
        if (!alive || mobs[i].health <= 0) {
            player.gainXP(mobs[i].xpValue);
            mobs.splice(i, 1);
        }
    }
}

export function drawMobs(ctx, viewX, viewY) {
    for (let mob of mobs) {
        mob.draw(ctx, viewX, viewY);
    }
}
