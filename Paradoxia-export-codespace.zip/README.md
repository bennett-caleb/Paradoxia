 # WebRPGGame

This repository contains a small browser-based Terraria-style RPG demo.

## New module layout (since refactor)

The front-end has been split into ES modules under `src/` for easier reuse and moving to other codespaces:

- `src/constants.js` — shared game constants (tile size, gravity, etc.)
- `src/input.js` — input state and bindings
- `src/world.js` — `World` class and terrain drawing
- `src/player.js` — `Player` class and player logic
- `src/mob.js` — `Mob` class and mob management
- `src/projectiles.js` — projectile update/draw logic
- `src/hud.js` — HUD update helper
- `src/game.js` — entry point, game loop, and bootstrapping (loaded as a module)

The app now uses `<script type="module" src="src/game.js"></script>` in `index.html`.

Note: the legacy `rpg-game.js` file has been removed; if you need a backup, check the commit history.
