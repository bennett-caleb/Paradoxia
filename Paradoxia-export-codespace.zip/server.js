// Secure static file server for WebRPGGame
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// Basic rate limiter: limit repeated requests to public APIs and static assets
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // limit each IP to 500 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Helmet helps set a variety of security headers
app.use(helmet({
  contentSecurityPolicy: false // we'll set CSP manually to avoid blocking dev setup
}));

// Content Security Policy: allow only same-origin resources
const cspDirectives = {
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'"],
    imgSrc: ["'self'", 'data:'],
    connectSrc: ["'self'"],
    objectSrc: ["'none'"],
    frameAncestors: ["'none'"],
    baseUri: ["'self'"],
    formAction: ["'self'"]
  }
};
app.use(helmet.contentSecurityPolicy(cspDirectives));

// Additional headers
app.use((req, res, next) => {
  // Prevent MIME-sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  // Referrer policy
  res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
  // Permissions policy (disable powerful features)
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  // HSTS only if request is secure
  if (req.secure || req.headers['x-forwarded-proto'] === 'https') {
    res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
  }
  next();
});

// Request logging middleware for debugging (records method, path, time)
app.use((req, res, next) => {
  try {
    const entry = `${new Date().toISOString()} ${req.ip} ${req.method} ${req.originalUrl}\n`;
    console.log(entry.trim());
    const fs = require('fs');
    fs.appendFileSync(path.join(__dirname, 'server_requests.log'), entry);
  } catch (e) {
    // ignore logging errors in dev
  }
  next();
});

// Serve static files from the project root
const staticPath = path.join(__dirname);
app.use(express.static(staticPath, {
  index: 'index.html',
  extensions: ['html'],
  // Do not show directory listings
  redirect: false,
  setHeaders: (res, filePath) => {
    // Set cache-control for static files (no-cache in dev)
    res.setHeader('Cache-Control', 'no-store');
    // Ensure JS served as JS
    if (filePath.endsWith('.js')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    }
  }
}));
// Endpoint to receive client-side error logs
app.post('/log', express.json({limit: '10kb'}), (req, res) => {
  try {
    const entry = {
      time: new Date().toISOString(),
      ip: req.ip,
      body: req.body
    };
    const line = JSON.stringify(entry) + '\n';
    const logFile = path.join(__dirname, 'server_errors.log');
    require('fs').appendFileSync(logFile, line);
  } catch (e) {
    // ignore
  }
  res.sendStatus(204);
});

// Catch-all route: return 404 for unknown endpoints (avoid exposing internals)
app.use((req, res) => {
  res.status(404).send('Not found');
});

app.listen(PORT, HOST, () => {
  console.log(`Secure server running at http://${HOST}:${PORT}`);
});
